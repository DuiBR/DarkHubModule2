#!/bin/bash

nome_usuario="$1"
senha="$2"
dias="$3"
limite_sessoes="$4"

[ ! -f /root/usuarios.db ] && touch /root/usuarios.db

bash /opt/darkapi/RemoveUser.sh "$nome_usuario" >/dev/null 2>&1

data_expira=$(date -d "+$((dias+1)) days" +%Y-%m-%d)
senha_criptografada=$(openssl passwd -1 "$senha")

useradd -M -s /bin/false -p "$senha_criptografada" -e "$data_expira" "$nome_usuario" >/dev/null 2>&1

mkdir -p /etc/SSHPlus/senha/ >/dev/null 2>&1
echo "$senha" > "/etc/SSHPlus/senha/$nome_usuario"
echo "$nome_usuario $limite_sessoes" >> /root/usuarios.db

echo "sucesso"
