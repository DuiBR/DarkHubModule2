#!/bin/bash

comando="$1"

if [ "$comando" == "reboot" ]; then
    echo "comandoenviadocomsucesso"
    nohup sudo reboot >/dev/null 2>&1 &
    exit 0

elif [ "$comando" == "status" ]; then
    cpu_usage=$(top -bn1 | awk '/Cpu/ { cpu = "" 100 - $8 "%" }; END { print cpu }')
    mem_usage=$(free -m | awk 'NR==2{printf "%.2f%%", $3*100/$2 }')
    echo "$cpu_usage $mem_usage"

elif [ "$comando" == "remover" ]; then
    sleep 3

    stop_and_disable_service() {
        local service_name=$1
        if systemctl is-active --quiet "$service_name"; then
            sudo systemctl stop "$service_name" >/dev/null 2>&1
            sudo systemctl disable "$service_name" >/dev/null 2>&1
        fi
    }

    stop_and_disable_service "ModuloSinc.service"

    sudo rm -rf /opt/darkapi >/dev/null 2>&1
    sudo rm /etc/systemd/system/ModuloSinc.service >/dev/null 2>&1

    port=9060
    sudo firewall-cmd --zone=public --remove-port=$port/tcp --permanent >/dev/null 2>&1
    sudo firewall-cmd --reload >/dev/null 2>&1
    sudo iptables -D INPUT -p tcp --dport $port -j ACCEPT >/dev/null 2>&1
    sudo iptables-save | sudo tee /etc/iptables/rules.v4 >/dev/null 2>&1
    sudo ufw delete allow $port/tcp >/dev/null 2>&1

    crontab -l | grep -v 'verificador.sh' | crontab - >/dev/null 2>&1
    sudo systemctl restart cron >/dev/null 2>&1

    echo "comandoenviadocomsucesso"
else
    echo "Invalid command"
fi
