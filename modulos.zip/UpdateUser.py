#!/usr/bin/env python3
import sys
import os
import subprocess
import crypt
from datetime import datetime, timedelta

usuario = sys.argv[1]
senha   = sys.argv[2]
dias    = int(sys.argv[3])
limite  = sys.argv[4]

# soma +1 dia ao prazo de expiração
exp = (datetime.now() + timedelta(days=dias+1)).strftime("%Y-%m-%d")

# gera hash da senha
hash_pwd = crypt.crypt(senha, crypt.mksalt(crypt.METHOD_MD5))

# garante que o usuário exista (se não existir, cria)
subprocess.run(
    ["id", "-u", usuario],
    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
)
if subprocess.call(["id", usuario], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL) != 0:
    subprocess.run([
        "useradd", "-M", "-s", "/bin/false", usuario
    ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

# atualiza a senha
subprocess.run(
    ["usermod", "-p", hash_pwd, usuario],
    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
)

# atualiza expiração da conta
subprocess.run(
    ["chage", "-E", exp, usuario],
    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
)

# salva senha em arquivo
os.makedirs("/etc/SSHPlus/senha/", exist_ok=True)
with open(f"/etc/SSHPlus/senha/{usuario}", "w") as f:
    f.write(senha)

# adiciona ou substitui no banco de usuários
def atualizar_usuario(caminho, usuario, limite):
    linhas = []
    if os.path.exists(caminho):
        with open(caminho, "r", encoding="utf-8") as f:
            for l in f:
                if not l.strip():
                    continue
                if not l.startswith(usuario + " "):
                    linhas.append(l.strip())
    linhas.append(f"{usuario} {limite}")
    with open(caminho, "w", encoding="utf-8") as f:
        f.write("\n".join(linhas) + "\n")

atualizar_usuario("/root/usuarios.db", usuario, limite)

print("sucesso")
