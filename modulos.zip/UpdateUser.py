#!/usr/bin/env python3
import sys
import os
import subprocess
import crypt
import json
import pwd
from datetime import datetime, timedelta

def update_user(username, password, days, limit, uuid=None):
    # Configurações de paths
    config_v2ray = "/etc/v2ray/config.json"
    config_xray = "/usr/local/etc/xray/config.json"
    senha_path = f"/etc/SSHPlus/senha/{username}"
    usuarios_db = "/root/usuarios.db"
    
    # Calcular data de expiração
    exp = (datetime.now() + timedelta(days=days)).strftime("%Y-%m-%d")
    hash_pwd = crypt.crypt(password, crypt.mksalt(crypt.METHOD_MD5))
    
    # Verificar se usuário existe e atualizar
    try:
        pwd.getpwnam(username)
        # Usuário existe - atualizar sem desconectar
        subprocess.run([
            "usermod", 
            "-p", hash_pwd, 
            "-e", exp, 
            username
        ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except KeyError:
        # Usuário não existe - criar novo
        subprocess.run([
            "useradd", "-M", "-s", "/bin/false",
            "-p", hash_pwd, "-e", exp, username
        ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    
    # Atualizar/mover arquivo de senha
    os.makedirs(os.path.dirname(senha_path), exist_ok=True)
    with open(senha_path, "w") as f:
        f.write(password)
    
    # Atualizar V2Ray/XRay se tiver UUID
    if uuid:
        novo_cliente = {"email": username, "id": uuid, "level": 0}
        
        # Atualizar V2Ray
        if os.path.isfile(config_v2ray):
            update_v2ray_config(config_v2ray, username, novo_cliente)
        
        # Atualizar XRay
        if os.path.isfile(config_xray):
            update_xray_config(config_xray, username, novo_cliente)
    else:
        # Remover de V2Ray/XRay se não tiver UUID
        if os.path.isfile(config_v2ray):
            remove_from_v2ray(config_v2ray, username)
        if os.path.isfile(config_xray):
            remove_from_xray(config_xray, username)
    
    # Atualizar database de usuários
    update_user_database(usuarios_db, username, limit)

def update_v2ray_config(config_path, username, new_client):
    try:
        with open(config_path, 'r') as f:
            data = json.load(f)
        
        # Encontrar e remover usuário existente
        clients = data.get('inbounds', [])[0].get('settings', {}).get('clients', [])
        filtered = [c for c in clients if c.get('email') != username]
        
        # Adicionar novo cliente
        filtered.append(new_client)
        data['inbounds'][0]['settings']['clients'] = filtered
        
        with open(config_path, 'w') as f:
            json.dump(data, f, indent=2)
        os.chmod(config_path, 0o777)
    except Exception as e:
        print(f"Erro ao atualizar V2Ray: {e}")

def update_xray_config(config_path, username, new_client):
    try:
        with open(config_path, 'r') as f:
            data = json.load(f)
        
        changed = False
        for ib in data.get('inbounds', []):
            if ib.get('tag') == 'inbound-sshplus':
                clients = ib.get('settings', {}).get('clients', [])
                filtered = [c for c in clients if c.get('email') != username]
                filtered.append(new_client)
                ib['settings']['clients'] = filtered
                changed = True
        
        if changed:
            with open(config_path, 'w') as f:
                json.dump(data, f, indent=2)
            os.chmod(config_path, 0o777)
    except Exception as e:
        print(f"Erro ao atualizar XRay: {e}")

def remove_from_v2ray(config_path, username):
    try:
        with open(config_path, 'r') as f:
            data = json.load(f)
        
        clients = data.get('inbounds', [])[0].get('settings', {}).get('clients', [])
        filtered = [c for c in clients if c.get('email') != username]
        data['inbounds'][0]['settings']['clients'] = filtered
        
        with open(config_path, 'w') as f:
            json.dump(data, f, indent=2)
        os.chmod(config_path, 0o777)
    except Exception:
        pass

def remove_from_xray(config_path, username):
    try:
        with open(config_path, 'r') as f:
            data = json.load(f)
        
        changed = False
        for ib in data.get('inbounds', []):
            if ib.get('tag') == 'inbound-sshplus':
                clients = ib.get('settings', {}).get('clients', [])
                filtered = [c for c in clients if c.get('email') != username]
                ib['settings']['clients'] = filtered
                changed = True
        
        if changed:
            with open(config_path, 'w') as f:
                json.dump(data, f, indent=2)
            os.chmod(config_path, 0o777)
    except Exception:
        pass

def update_user_database(db_path, username, limit):
    lines = []
    if os.path.isfile(db_path):
        with open(db_path, 'r') as f:
            lines = [l.strip() for l in f if l.strip()]
    
    # Remover entradas existentes para este usuário
    lines = [line for line in lines if not line.startswith(f"{username} ")]
    
    # Adicionar nova entrada
    lines.append(f"{username} {limit}")
    
    with open(db_path, 'w') as f:
        f.write("\n".join(lines) + "\n")

if __name__ == "__main__":
    if len(sys.argv) == 5:
        # Chamada sem UUID (AddUser.py)
        username, password, days, limit = sys.argv[1:5]
        update_user(username, password, int(days), limit)
        print("sucesso")
    elif len(sys.argv) == 6:
        # Chamada com UUID (AddSincV2.py)
        uuid, username, password, days, limit = sys.argv[1:6]
        update_user(username, password, int(days), limit, uuid)
        print("sucesso")
    else:
        print("error")
        sys.exit(1)