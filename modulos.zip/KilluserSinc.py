#!/usr/bin/env python3
import os
import sys
import subprocess
import logging

log_file_path = "/opt/darkapi/killuser_log.txt"
max_log_size = 512 * 1024

def rotate_log():
    if os.path.exists(log_file_path) and os.path.getsize(log_file_path) > max_log_size:
        os.remove(log_file_path)

def setup_logger():
    logging.basicConfig(
        filename=log_file_path,
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s"
    )

def main():
    response = "error"
    setup_logger()
    rotate_log()

    if len(sys.argv) < 2:
        logging.error("Arquivo de log não especificado.")
        print(response)
        sys.exit(1)

    nome_arquivo = sys.argv[1]

    if not os.path.exists(nome_arquivo):
        logging.error(f"Arquivo não encontrado: {nome_arquivo}")
        print(response)
        sys.exit(1)

    try:
        with open(nome_arquivo, 'r', encoding='utf-8') as arquivo:
            linhas = [linha.strip() for linha in arquivo if linha.strip()]

        if not linhas:
            logging.warning(f"Arquivo {nome_arquivo} vazio. Nada a processar.")
            os.remove(nome_arquivo)
            print("sucesso")
            sys.exit(0)

        for linha in linhas:
            try:
                subprocess.run(
                    ["bash", "/opt/darkapi/Killuser.sh", linha],
                    check=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )
                logging.info(f"Processado com sucesso: {linha}")
            except subprocess.CalledProcessError as e:
                logging.error(f"Erro ao processar '{linha}': {e.stderr.decode().strip()}")

        os.remove(nome_arquivo)
        print("sucesso")
        sys.exit(0)

    except Exception as e:
        logging.error(f"Erro inesperado: {e}")
        if os.path.exists(nome_arquivo):
            os.remove(nome_arquivo)
        print(response)
        sys.exit(1)

if __name__ == "__main__":
    main()
