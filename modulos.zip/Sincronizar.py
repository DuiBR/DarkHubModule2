#!/usr/bin/env python3
import os
import sys
import subprocess
import json
import logging
import traceback
from datetime import datetime

log_file_path = "/opt/darkapi/sincronizar.log"
max_log_size = 3 * 1024 * 1024
python_path = sys.executable

def rotate_log():
    if os.path.exists(log_file_path) and os.path.getsize(log_file_path) > max_log_size:
        os.remove(log_file_path)

def setup_logger():
    logging.basicConfig(
        filename=log_file_path,
        level=logging.INFO,
        format="%(asctime)s - %(message)s",
        force=True
    )

def log(msg):
    logging.info(msg)

def remover_duplicados_v2ray(path):
    if not os.path.exists(path):
        return
    try:
        with open(path, 'r') as f:
            data = json.load(f)
        seen_ids = set()
        seen_emails = set()
        clients = []
        for client in data["inbounds"][0]["settings"]["clients"]:
            cid = client.get("id")
            email = client.get("email")
            if cid in seen_ids or email in seen_emails:
                continue
            seen_ids.add(cid)
            seen_emails.add(email)
            clients.append(client)
        data["inbounds"][0]["settings"]["clients"] = clients
        with open(path, 'w') as f:
            json.dump(data, f, indent=2)
        os.chmod(path, 0o777)
    except Exception as e:
        log(f"Erro ao limpar duplicatas V2Ray: {e}")

def remover_duplicados_xray(path):
    if not os.path.exists(path):
        return
    try:
        with open(path, 'r') as f:
            data = json.load(f)
        for inbound in data.get("inbounds", []):
            if inbound.get("tag") != "inbound-sshplus":
                continue
            seen_ids = set()
            seen_emails = set()
            clients = []
            for client in inbound.get("settings", {}).get("clients", []):
                cid = client.get("id")
                email = client.get("email")
                if cid in seen_ids or email in seen_emails:
                    continue
                seen_ids.add(cid)
                seen_emails.add(email)
                clients.append(client)
            inbound["settings"]["clients"] = clients
        with open(path, 'w') as f:
            json.dump(data, f, indent=2)
        os.chmod(path, 0o777)
    except Exception as e:
        log(f"Erro ao limpar duplicatas XRay: {e}")

def reiniciar_servicos():
    remover_duplicados_v2ray("/etc/v2ray/config.json")
    remover_duplicados_xray("/usr/local/etc/xray/config.json")
    for servico, cfg in {
        "v2ray": "/etc/v2ray/config.json",
        "xray": "/usr/local/etc/xray/config.json"
    }.items():
        if not os.path.exists(cfg):
            continue
        try:
            ativo = subprocess.run(["systemctl", "is-active", "--quiet", servico]).returncode == 0
            subprocess.run(["systemctl", "restart" if ativo else "start", servico], check=True)
            log(f"Serviço {servico} reiniciado com sucesso.")
        except Exception as e:
            log(f"Erro ao reiniciar {servico}: {e}")

def executar(cmd):
    try:
        log(f"Executando comando: {' '.join(cmd)}")
        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        log("✔️ Comando executado com sucesso")
    except Exception as e:
        log(f"❌ Erro ao executar: {' '.join(cmd)}\n{e}")

def main():
    rotate_log()
    setup_logger()
    log("==== INÍCIO ====")

    if len(sys.argv) < 2:
        print("error")
        return 1

    nome_arquivo = sys.argv[1]
    if not os.path.exists(nome_arquivo):
        print("error")
        return 1

    try:
        with open(nome_arquivo, 'r', encoding='utf-8') as f:
            linhas = [l.strip() for l in f if l.strip()]

        if not linhas:
            os.remove(nome_arquivo)
            print("error")
            return 1

        for linha in linhas:
            col = linha.split()
            if len(col) >= 5:
                executar([
                    python_path,
                    "/opt/darkapi/AddSincV2.py",
                    col[4], col[0], col[1], col[2], col[3]
                ])
            elif len(col) >= 4:
                executar([
                    python_path,
                    "/opt/darkapi/AddUser.py",
                    col[0], col[1], col[2], col[3]
                ])

        os.remove(nome_arquivo)
        reiniciar_servicos()

        log("==== FIM ====\n\n")
        print("comandoenviadocomsucesso")
        return 0

    except Exception as e:
        log(f"Erro geral: {e}\n{traceback.format_exc()}")
        if os.path.exists(nome_arquivo):
            os.remove(nome_arquivo)
        print("error")
        return 1

if __name__ == "__main__":
    sys.exit(main())
