#!/usr/bin/env python3
import os
import sys
import json
import subprocess
import logging
import traceback

log_file_path = "/opt/darkapi/sincronizar.log"
python_path = sys.executable

V2RAY_CFG = "/etc/v2ray/config.json"
XRAY_CFG = "/usr/local/etc/xray/config.json"

def setup_logger():
    logging.basicConfig(
        filename=log_file_path,
        level=logging.INFO,
        format="%(asctime)s - %(message)s",
        force=True
    )
    logging.info("==== INÍCIO ====")

def log(msg):
    logging.info(msg)

def ler_usuarios_vps():
    usuarios = set()
    for path in [V2RAY_CFG, XRAY_CFG]:
        if not os.path.exists(path):
            continue
        try:
            with open(path, 'r') as f:
                data = json.load(f)
            for inbound in data.get("inbounds", []):
                for client in inbound.get("settings", {}).get("clients", []):
                    if client.get("email"):
                        usuarios.add(client["email"])
        except Exception as e:
            log(f"Erro ao ler {path}: {e}")
    return usuarios

def remover_duplicados_v2ray(path):
    if not os.path.exists(path):
        return
    try:
        with open(path, 'r') as f:
            data = json.load(f)
        seen_ids = set()
        seen_emails = set()
        clients = []
        for client in data["inbounds"][0]["settings"]["clients"]:
            cid = client.get("id")
            email = client.get("email")
            if cid in seen_ids or email in seen_emails:
                continue
            seen_ids.add(cid)
            seen_emails.add(email)
            clients.append(client)
        data["inbounds"][0]["settings"]["clients"] = clients
        with open(path, 'w') as f:
            json.dump(data, f, indent=2)
        os.chmod(path, 0o777)
    except Exception as e:
        log(f"Erro ao limpar duplicatas V2Ray: {e}")

def remover_duplicados_xray(path):
    if not os.path.exists(path):
        return
    try:
        with open(path, 'r') as f:
            data = json.load(f)
        for inbound in data.get("inbounds", []):
            if inbound.get("tag") != "inbound-sshplus":
                continue
            seen_ids = set()
            seen_emails = set()
            clients = []
            for client in inbound.get("settings", {}).get("clients", []):
                cid = client.get("id")
                email = client.get("email")
                if cid in seen_ids or email in seen_emails:
                    continue
                seen_ids.add(cid)
                seen_emails.add(email)
                clients.append(client)
            inbound["settings"]["clients"] = clients
        with open(path, 'w') as f:
            json.dump(data, f, indent=2)
        os.chmod(path, 0o777)
    except Exception as e:
        log(f"Erro ao limpar duplicatas XRay: {e}")

def reiniciar_servicos():
    remover_duplicados_v2ray(V2RAY_CFG)
    remover_duplicados_xray(XRAY_CFG)
    for servico in ["v2ray", "xray"]:
        try:
            ativo = subprocess.run(["systemctl", "is-active", "--quiet", servico]).returncode == 0
            subprocess.run(["systemctl", "restart" if ativo else "start", servico], check=True)
            log(f"Serviço {servico} reiniciado.")
        except Exception as e:
            log(f"Erro ao reiniciar {servico}: {e}")

def executar(cmd):
    try:
        log(f"Executando comando: {' '.join(cmd)}")
        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        log("✔️ Comando executado com sucesso")
    except Exception as e:
        log(f"❌ Erro ao executar: {' '.join(cmd)}\n{e}")

def main():
    setup_logger()

    if len(sys.argv) < 2:
        print("error")
        return 1

    nome_arquivo = sys.argv[1]
    if not os.path.exists(nome_arquivo):
        print("error")
        return 1

    try:
        # --- Carrega todos os usuários enviados pelo painel ---
        with open(nome_arquivo, 'r', encoding='utf-8') as f:
            linhas = [l.strip() for l in f if l.strip()]

        if not linhas:
            os.remove(nome_arquivo)
            print("error")
            return 1

        painel_usuarios = set()
        for linha in linhas:
            col = linha.split()
            if len(col) >= 5:
                painel_usuarios.add(col[4])  # email
            elif len(col) >= 4:
                painel_usuarios.add(col[0])  # login como email

        # --- Usuários que já estão na VPS ---
        vps_usuarios = ler_usuarios_vps()

        # --- Adicionar usuários novos ---
        for linha in linhas:
            col = linha.split()
            if len(col) >= 5 and col[4] not in vps_usuarios:
                executar([python_path, "/opt/darkapi/AddSincV2.py", col[4], col[0], col[1], col[2], col[3]])
            elif len(col) >= 4 and col[0] not in vps_usuarios:
                executar([python_path, "/opt/darkapi/AddUser.py", col[0], col[1], col[2], col[3]])

        # --- Remover usuários que estão na VPS mas não estão no painel ---
        for usuario in vps_usuarios - painel_usuarios:
            executar(["bash", "/opt/darkapi/RemoveUser.sh", usuario])

        os.remove(nome_arquivo)
        reiniciar_servicos()
        log("==== FIM ====")
        print("comandoenviadocomsucesso")
        return 0

    except Exception as e:
        log(f"Erro geral: {e}\n{traceback.format_exc()}")
        if os.path.exists(nome_arquivo):
            os.remove(nome_arquivo)
        print("error")
        return 1

if __name__ == "__main__":
    sys.exit(main())
